<template>
  <div id="app2">
   
    <!-- <img src="./assets/logo.png" /> -->
    <!-- <router-view /> -->
    <!-- <router-link to="/">To Avia 2 Click</router-link> -->
     AVIA!!!!
  </div>
</template>

<script>
export default {
  name: "app2"
};
</script>

<style>
#app2 {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #e21a5d;
  margin-top: 60px;
}
</style>